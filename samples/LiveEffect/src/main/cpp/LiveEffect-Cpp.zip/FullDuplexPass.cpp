////
//// Created by MonkeyMaster on 18.10.2022.
////
//
//#include "FullDuplexPass.h"
//
//// Define static variables once
//bool FullDuplexPass::hannCoeffsCalculated = false;
//float* FullDuplexPass::prevInputFloats = new float[256]{}; // Fill with zeros at init
//float* FullDuplexPass::hannCoeffs = new float[256]{};
